import { c as defineEventHandler, u as useRuntimeConfig, e as createError, r as readBody, g as getHeader } from '../../_/nitro.mjs';
import { z } from 'zod';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue-router';
import 'node:fs';
import 'node:path';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';

const ContactSchema = z.object({
  name: z.string().min(2).max(100).trim(),
  email: z.string().email().max(200).trim().toLowerCase(),
  interest: z.string().max(100).optional(),
  message: z.string().min(10).max(2e3).trim()
});
const contact_post = defineEventHandler(async (event) => {
  const { contactEmail } = useRuntimeConfig();
  if (!contactEmail) {
    throw createError({
      statusCode: 500,
      statusMessage: "Configuraci\xF3n de servidor incompleta"
    });
  }
  const raw = await readBody(event);
  const parsed = ContactSchema.safeParse(raw);
  if (!parsed.success) {
    throw createError({
      statusCode: 400,
      statusMessage: "Datos del formulario inv\xE1lidos",
      data: parsed.error.flatten().fieldErrors
    });
  }
  const { name, email, interest, message } = parsed.data;
  const origin = getHeader(event, "origin") || "http://localhost:3000";
  try {
    await $fetch(`https://formsubmit.co/ajax/${contactEmail}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "Origin": origin,
        "Referer": `${origin}/`
      },
      body: {
        nombre: name,
        email,
        servicio: interest != null ? interest : "No especificado",
        mensaje: message,
        _subject: `\u{1F680} Nuevo Lead: ${name}`,
        _template: "table",
        _captcha: "false"
      }
    });
    return { success: true };
  } catch {
    throw createError({
      statusCode: 502,
      statusMessage: "Error al procesar el env\xEDo del formulario con el proveedor externo."
    });
  }
});

export { contact_post as default };
//# sourceMappingURL=contact.post.mjs.map
